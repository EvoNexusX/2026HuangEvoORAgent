import matplotlib.pyplot as plt
import numpy as np

# Data from table
N = np.array([6, 8, 10, 12, 14, 16, 18, 20])
train = np.array([76.2, 80.5, 82.6, 83.1, 83.4, 83.6, 83.8, 84.1])
test = np.array([73.1, 76.8, 79.3, 79.6, 79.8, 80.1, 80.3, 80.5])
delta_test = np.array([0, 3.7, 2.5, 0.3, 0.2, 0.3, 0.2, 0.2])  # first is dummy

# Style (IEEE-friendly)
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 11,
    "axes.labelsize": 12,
    "legend.fontsize": 10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
})

fig, ax1 = plt.subplots(figsize=(6.5, 4.5))

# Color palette (colorblind-friendly)
color_train = "#4C72B0"  # blue
color_test = "#DD8452"   # orange
color_delta = "#55A868"  # green

# ---- Main curves ----
ax1.plot(N, train, marker='o', linewidth=2.2, color=color_train, label='Train WA')
ax1.plot(N, test, marker='s', linewidth=2.2, color=color_test, label='Test WA')

ax1.set_xlabel("Population Size (N)")
ax1.set_ylabel("Weighted Accuracy (WA, %)")

ax1.set_xlim(5.5, 20.5)
ax1.set_ylim(72, 85)

# Grid (light, publication style)
ax1.grid(True, linestyle='--', linewidth=0.6, alpha=0.6)

# ---- Secondary axis for Δ Test ----
ax2 = ax1.twinx()
ax2.bar(N, delta_test, width=1.2, alpha=0.25, color=color_delta, label='Δ Test')

ax2.set_ylabel("Δ Test (%)")
ax2.set_ylim(0, 4.5)

# ---- Highlight Elbow Point ----
elbow_x = 10
elbow_y = 79.3

ax1.scatter(elbow_x, elbow_y, color='red', zorder=5)
ax1.annotate(
    "Elbow Point (N=10)",
    xy=(elbow_x, elbow_y),
    xytext=(11.5, 77.5),
    arrowprops=dict(arrowstyle="->", lw=1.2),
    fontsize=10
)

# ---- Legend (combined) ----
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc="lower right", frameon=True)

plt.tight_layout()
plt.savefig("population_size_analysis.pdf", dpi=600, bbox_inches='tight')
plt.savefig("population_size_analysis.png", dpi=600, bbox_inches='tight')

plt.show()